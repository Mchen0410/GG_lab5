<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 2: Comparación de estructuras
// repetitivas: for, while y do...while (sin sustituir una por otra)
// ==============================================================
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ejercicio 2 - Estructuras repetitivas</title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; padding:24px; }
    .card { max-width:680px; margin:0 auto 20px; background:#fff; border-radius:10px;
            box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    h1 { font-size:1.3rem; color:#1a5fb4; margin-top:0; }
    h2 { font-size:1.1rem; color:#333; }
    .lista { columns:2; list-style:none; padding:0; }
    .lista li { padding:3px 8px; border-bottom:1px solid #eee; }
    .par   { color:#1a5fb4; font-weight:bold; }
    .impar { color:#c01c28; font-weight:bold; }
    .resultado { background:#e8f5e9; border:1px solid #a5d6a7; border-radius:8px;
                 padding:10px 14px; font-weight:bold; }
    .despegue { background:#fff3e0; border:1px solid #ffcc80; border-radius:8px;
                padding:10px 14px; font-weight:bold; color:#e65100; }
</style>
</head>
<body>

<div class="card">
    <h1>Ejercicio 2a: for &mdash; Números del 1 al 20 (par / impar)</h1>
    <ul class="lista">
        <?php
        // a) FOR: números del 1 al 20 indicando par o impar (operador %)
        for ($i = 1; $i <= 20; $i++) {
            $tipo = ($i % 2 === 0) ? 'par' : 'impar'; // operador relacional y módulo
            echo "<li>$i &rarr; <span class=\"$tipo\">$tipo</span></li>";
        }
        ?>
    </ul>
</div>

<div class="card">
    <h1>Ejercicio 2b: while &mdash; Suma acumulada del 1 al 100</h1>
    <?php
    // b) WHILE: suma acumulada de los enteros del 1 al 100
    $n = 1;
    $acumulada = 0;
    while ($n <= 100) {
        $acumulada += $n; // acumulador
        $n++;             // incremento
    }
    echo "<p class='resultado'>Suma acumulada de 1 a 100 = $acumulada</p>";
    ?>
</div>

<div class="card">
    <h1>Ejercicio 2c: do...while &mdash; Cuenta regresiva</h1>
    <?php
    // c) DO...WHILE: cuenta regresiva del 10 al 1
    $c = 10;
    do {
        echo "<p>$c</p>";
        $c--; // decremento
    } while ($c >= 1);
    echo "<p class='despegue'>¡Despegue!</p>";
    ?>
</div>

</body>
</html>
