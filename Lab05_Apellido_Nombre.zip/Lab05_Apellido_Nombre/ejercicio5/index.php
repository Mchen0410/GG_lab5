<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 5: Gestión de productos con
// clases y objetos. Clases, propiedades, métodos, arreglos de
// objetos y foreach.
// ==============================================================

class Producto
{
    // Propiedades protegidas (accesibles desde la clase y sus hijas)
    protected $codigo;
    protected $nombre;
    protected $precio;
    protected $cantidad;

    // Constructor: inicializa las propiedades del objeto
    public function __construct(string $codigo, string $nombre, float $precio, int $cantidad)
    {
        $this->codigo   = $codigo;
        $this->nombre   = $nombre;
        $this->precio   = $precio;
        $this->cantidad = $cantidad;
    }

    // Devuelve la información formateada del producto
    public function obtenerInformacion(): string
    {
        return sprintf("[%s] %s — Precio: $%.2f — Cantidad: %d",
            $this->codigo, $this->nombre, $this->precio, $this->cantidad);
    }

    // Calcula el valor de inventario del producto: precio × cantidad
    public function valorInventario(): float
    {
        return $this->precio * $this->cantidad;
    }

    // Determina si el producto tiene existencia disponible
    public function tieneExistencia(): bool
    {
        return $this->cantidad > 0;
    }
}

// Creación de 3 objetos Producto almacenados en un arreglo
$productos = [
    new Producto('P-001', 'Monitor LED 24"',  185.00, 10),
    new Producto('P-002', 'Teclado mecánico',  75.50,  0), // sin existencia
    new Producto('P-003', 'Disco SSD 1TB',     98.75,  5),
];

// Valor total del inventario, recorriendo el arreglo de objetos con foreach
$totalInventario = 0;
foreach ($productos as $p) {
    $totalInventario += $p->valorInventario();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ejercicio 5 - Clases y objetos</title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; padding:24px; }
    .card { max-width:720px; margin:0 auto; background:#fff; border-radius:10px;
            box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    h1 { font-size:1.3rem; color:#1a5fb4; margin-top:0; }
    table { border-collapse:collapse; width:100%; }
    th, td { border:1px solid #d0d7de; padding:8px 10px; text-align:left; }
    th { background:#1a5fb4; color:#fff; }
    td.num { text-align:right; }
    .ok { color:#2e7d32; font-weight:bold; }
    .agotado { color:#c01c28; font-weight:bold; }
    .resumen { margin-top:16px; background:#e8f5e9; border:1px solid #a5d6a7;
               border-radius:8px; padding:14px; font-weight:bold; color:#2e7d32; }
</style>
</head>
<body>
<div class="card">
    <h1>Ejercicio 5: Gestión de productos con clases y objetos</h1>
    <table>
        <tr><th>Información</th><th>Valor inventario ($)</th><th>Existencia</th></tr>
        <?php foreach ($productos as $p): ?>
            <tr>
                <td><?= htmlspecialchars($p->obtenerInformacion(), ENT_QUOTES, 'UTF-8') ?></td>
                <td class="num"><?= number_format($p->valorInventario(), 2) ?></td>
                <td><?= $p->tieneExistencia()
                        ? '<span class="ok">Disponible</span>'
                        : '<span class="agotado">Agotado</span>' ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <div class="resumen">
        Valor total del inventario: $<?= number_format($totalInventario, 2) ?>
    </div>
</div>
</body>
</html>
