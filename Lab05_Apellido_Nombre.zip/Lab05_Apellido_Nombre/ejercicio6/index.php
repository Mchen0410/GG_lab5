<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 6: Sistema de pedidos con manejo de
// excepciones. Clases, constantes, throw y try/catch.
// ==============================================================

class Pedido
{
    // Constante de clase: porcentaje de impuesto (7% ITBMS)
    const IMPUESTO = 0.07;

    // Propiedades
    private $cliente;
    private $producto;
    private $precio;
    private $cantidad;

    // Constructor: valida datos antes de crear el pedido
    public function __construct(string $cliente, string $producto, float $precio, int $cantidad)
    {
        if ($precio <= 0) {
            throw new Exception("El precio debe ser mayor que cero (recibido: $precio).");
        }
        if ($cantidad <= 0) {
            throw new Exception("La cantidad debe ser mayor que cero (recibida: $cantidad).");
        }
        $this->cliente  = $cliente;
        $this->producto = $producto;
        $this->precio   = $precio;
        $this->cantidad = $cantidad;
    }

    // Subtotal: precio × cantidad
    public function calcularSubtotal(): float
    {
        return $this->precio * $this->cantidad;
    }

    // Impuesto: subtotal × IMPUESTO (constante de clase)
    public function calcularImpuesto(): float
    {
        return $this->calcularSubtotal() * self::IMPUESTO;
    }

    // Total final: subtotal + impuesto
    public function calcularTotal(): float
    {
        return $this->calcularSubtotal() + $this->calcularImpuesto();
    }

    // Devuelve el resumen formateado del pedido
    public function mostrarResumen(): string
    {
        return sprintf(
            "Cliente: %s | Producto: %s | Precio: $%.2f | Cantidad: %d | Subtotal: $%.2f | Impuesto (%.0f%%): $%.2f | Total: $%.2f",
            $this->cliente, $this->producto, $this->precio, $this->cantidad,
            $this->calcularSubtotal(), self::IMPUESTO * 100,
            $this->calcularImpuesto(), $this->calcularTotal()
        );
    }
}

// ---------- Pruebas obligatorias dentro de bloques try / catch ----------

// Caso 1: pedido válido - Ana Pérez / Monitor / 185.00 / 2
$resultadoValido = '';
try {
    $pedido1 = new Pedido('Ana Pérez', 'Monitor', 185.00, 2);
    $resultadoValido = $pedido1->mostrarResumen();
} catch (Exception $e) {
    $resultadoValido = 'Error: ' . $e->getMessage();
}

// Caso 2: pedido inválido - Carlos Díaz / Teclado / 25.00 / 0 (lanza excepción)
$resultadoInvalido = '';
try {
    $pedido2 = new Pedido('Carlos Díaz', 'Teclado', 25.00, 0);
    $resultadoInvalido = $pedido2->mostrarResumen(); // nunca se alcanza
} catch (Exception $e) {
    $resultadoInvalido = 'Excepción capturada: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ejercicio 6 - Sistema de pedidos con excepciones</title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; padding:24px; }
    .card { max-width:760px; margin:0 auto; background:#fff; border-radius:10px;
            box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    h1 { font-size:1.3rem; color:#1a5fb4; margin-top:0; }
    h2 { font-size:1.05rem; }
    .valido { background:#e8f5e9; border:1px solid #a5d6a7; border-radius:8px;
              padding:12px 16px; }
    .error  { background:#ffebee; border:1px solid #ef9a9a; border-radius:8px;
              padding:12px 16px; color:#b71c1c; font-weight:bold; }
</style>
</head>
<body>
<div class="card">
    <h1>Ejercicio 6: Sistema de pedidos con manejo de excepciones</h1>

    <h2>Caso 1: pedido válido (Ana Pérez / Monitor / 185.00 / 2)</h2>
    <p class="valido"><?= htmlspecialchars($resultadoValido, ENT_QUOTES, 'UTF-8') ?></p>

    <h2>Caso 2: pedido inválido (Carlos Díaz / Teclado / 25.00 / 0)</h2>
    <p class="error"><?= htmlspecialchars($resultadoInvalido, ENT_QUOTES, 'UTF-8') ?></p>
</div>
</body>
</html>
