<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 3: Catálogo de productos
// Arreglos multidimensionales asociativos, funciones y foreach.
// ==============================================================

// Arreglo multidimensional asociativo con 5 productos
$productos = [
    ['nombre' => 'Monitor LED 24"',  'precio' => 185.00, 'cantidad' => 10],
    ['nombre' => 'Teclado mecánico', 'precio' =>  75.50, 'cantidad' =>  4],
    ['nombre' => 'Mouse inalámbrico','precio' =>  25.99, 'cantidad' => 20],
    ['nombre' => 'Disco SSD 1TB',    'precio' =>  98.75, 'cantidad' =>  3],
    ['nombre' => 'Webcam Full HD',   'precio' =>  42.30, 'cantidad' =>  7],
];

/**
 * Calcula el valor de inventario de un producto: precio × cantidad.
 */
function valorInventario(array $producto): float
{
    return $producto['precio'] * $producto['cantidad'];
}

/**
 * Calcula el valor total del inventario recorriendo el arreglo con foreach.
 */
function valorTotalInventario(array $productos): float
{
    $total = 0;
    foreach ($productos as $p) {
        $total += valorInventario($p); // se reutiliza la función, sin repetir código
    }
    return $total;
}

/**
 * Cuenta cuántos productos tienen existencia inferior a 5 unidades.
 */
function contarExistenciaBaja(array $productos, int $minimo = 5): int
{
    $contador = 0;
    foreach ($productos as $p) {
        if ($p['cantidad'] < $minimo) { // operador relacional <
            $contador++;
        }
    }
    return $contador;
}

/**
 * Renderiza la tabla HTML del catálogo recorriéndolo con foreach.
 */
function renderizarTabla(array $productos): string
{
    $html  = '<table><tr><th>#</th><th>Producto</th><th>Precio ($)</th>';
    $html .= '<th>Cantidad</th><th>Valor inventario ($)</th></tr>';
    foreach ($productos as $i => $p) {
        $valor = valorInventario($p);
        $fila  = $i + 1;
        $html .= '<tr>'
               . '<td>' . $fila . '</td>'
               . '<td>' . htmlspecialchars($p['nombre'], ENT_QUOTES, 'UTF-8') . '</td>'
               . '<td class="num">' . number_format($p['precio'], 2) . '</td>'
               . '<td class="num">' . $p['cantidad'] . '</td>'
               . '<td class="num">' . number_format($valor, 2) . '</td>'
               . '</tr>';
    }
    $html .= '</table>';
    return $html;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ejercicio 3 - Catálogo de productos</title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; padding:24px; }
    .card { max-width:720px; margin:0 auto; background:#fff; border-radius:10px;
            box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    h1 { font-size:1.3rem; color:#1a5fb4; margin-top:0; }
    table { border-collapse:collapse; width:100%; }
    th, td { border:1px solid #d0d7de; padding:8px 10px; text-align:left; }
    th { background:#1a5fb4; color:#fff; }
    td.num { text-align:right; }
    .resumen { margin-top:16px; background:#e8f5e9; border:1px solid #a5d6a7;
               border-radius:8px; padding:14px; }
    .resumen strong { color:#2e7d32; }
</style>
</head>
<body>
<div class="card">
    <h1>Ejercicio 3: Catálogo de productos</h1>
    <?= renderizarTabla($productos) ?>

    <div class="resumen">
        <p>Valor total del inventario:
            <strong>$<?= number_format(valorTotalInventario($productos), 2) ?></strong></p>
        <p>Productos con existencia inferior a 5 unidades:
            <strong><?= contarExistenciaBaja($productos) ?></strong></p>
    </div>
</div>
</body>
</html>
