<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 4: página de Productos
// Reutiliza los mismos archivos comunes mediante require/include.
// Usa la constante ITBMS para calcular precios con impuesto.
// ==============================================================

require __DIR__ . '/config/configuracion.php'; // crítico: sin constantes no hay cálculo
include __DIR__ . '/includes/encabezado.php';

$productos = [
    ['nombre' => 'Monitor LED 24"',  'precio' => 185.00],
    ['nombre' => 'Teclado mecánico', 'precio' =>  75.50],
    ['nombre' => 'Mouse inalámbrico','precio' =>  25.99],
];
?>

<h2>Catálogo de productos</h2>
<table>
    <tr><th>Producto</th><th>Precio base ($)</th><th>ITBMS ($)</th><th>Precio final ($)</th></tr>
    <?php foreach ($productos as $p):
        $impuesto = $p['precio'] * ITBMS;          // cálculo con la constante
        $final    = $p['precio'] + $impuesto;      // precio final con impuesto
    ?>
        <tr>
            <td><?= htmlspecialchars($p['nombre'], ENT_QUOTES, 'UTF-8') ?></td>
            <td class="num"><?= number_format($p['precio'], 2) ?></td>
            <td class="num"><?= number_format($impuesto, 2) ?></td>
            <td class="num"><?= number_format($final, 2) ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include __DIR__ . '/includes/pie.php'; ?>
