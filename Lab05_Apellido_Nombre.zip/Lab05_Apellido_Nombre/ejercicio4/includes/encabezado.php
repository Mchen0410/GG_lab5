<?php
// Encabezado común del sitio: usa la constante definida en configuracion.php
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title><?= EMPRESA_NOMBRE ?></title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; margin:0; }
    header { background:#1a5fb4; color:#fff; padding:16px 24px; }
    header h1 { margin:0; font-size:1.3rem; }
    nav { background:#154a8a; padding:10px 24px; }
    nav a { color:#fff; text-decoration:none; margin-right:18px; font-weight:bold; }
    nav a:hover { text-decoration:underline; }
    main { max-width:720px; margin:24px auto; background:#fff; border-radius:10px;
           box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    footer { text-align:center; color:#666; padding:16px; font-size:.85rem; }
    table { border-collapse:collapse; width:100%; }
    th, td { border:1px solid #d0d7de; padding:8px 10px; text-align:left; }
    th { background:#1a5fb4; color:#fff; }
    td.num { text-align:right; }
</style>
</head>
<body>
<header>
    <h1><?= EMPRESA_NOMBRE ?></h1>
</header>
<nav>
    <a href="index.php">Inicio</a>
    <a href="productos.php">Productos</a>
</nav>
<main>
