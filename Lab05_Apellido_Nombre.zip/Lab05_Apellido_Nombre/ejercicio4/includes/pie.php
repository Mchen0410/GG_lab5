</main>
<footer>
    <p>&copy; <?= date('Y') ?> <?= EMPRESA_NOMBRE ?> &mdash; Todos los derechos reservados.</p>
</footer>
</body>
</html>
