<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 4: Sitio modular (include y require)
// Página de inicio: reutiliza configuración, encabezado y pie.
// ==============================================================

/*
 * DIFERENCIA ENTRE include Y require CUANDO EL ARCHIVO NO EXISTE
 * -------------------------------------------------------------
 * require: si el archivo solicitado no puede encontrarse, PHP emite
 *          un E_WARNING y luego un ERROR FATAL (E_COMPILE_ERROR) que
 *          DETIENE por completo la ejecución del script. Se usa para
 *          archivos críticos sin los cuales la página no puede
 *          funcionar (ej. la configuración con las constantes).
 *
 * include: si el archivo no existe, PHP emite solo un E_WARNING
 *          (Warning) y el script CONTINÚA ejecutándose. Se usa para
 *          archivos opcionales o de presentación (ej. encabezado/pie).
 *
 * Prueba del laboratorio: al renombrar temporalmente
 * config/configuracion.php y recargar index.php, el require provoca
 * un Fatal error y la página queda en blanco; en cambio, al renombrar
 * includes/pie.php, el include muestra un Warning pero el resto de la
 * página sigue renderizándose.
 */

require __DIR__ . '/config/configuracion.php'; // archivo crítico: Fatal error si falta
include __DIR__ . '/includes/encabezado.php';  // archivo de presentación: Warning si falta
?>

<h2>Bienvenido a <?= EMPRESA_NOMBRE ?></h2>
<p>Somos una empresa dedicada a la venta de equipos tecnológicos en Panamá.
   Todas nuestras facturas aplican un ITBMS del <?= number_format(ITBMS * 100, 2) ?>%.</p>
<p>Visite la sección de <a href="productos.php">Productos</a> para conocer
   nuestro catálogo con precios e impuestos calculados.</p>

<?php include __DIR__ . '/includes/pie.php'; ?>
