<?php
// ==============================================================
// Configuración global del sitio (Ejercicio 4)
// Define constantes: se requiere mediante require para que la
// página falle (fatal error) si este archivo crítico no existe.
// ==============================================================

define('EMPRESA_NOMBRE', 'Tecnología Panamá, S.A.');
define('ITBMS', 0.07); // Porcentaje de ITBMS aplicable (7%)
