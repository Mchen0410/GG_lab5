<?php
// ==============================================================
// Laboratorio #5 - Ejercicio 1: Estadísticas de calificaciones
// Arreglos, foreach, acumuladores, contadores y operaciones
// aritméticas.
// ==============================================================

// Arreglo con las 10 notas solicitadas
$notas = [78, 95, 67, 88, 91, 72, 60, 84, 100, 76];

// Acumuladores y contadores
$cantidad   = count($notas);   // Cantidad total de estudiantes
$suma       = 0;               // Acumulador de la suma
$maxima     = $notas[0];       // Nota más alta
$minima     = $notas[0];       // Nota más baja
$aprobados  = 0;               // Contador: nota >= 71
$reprobados = 0;               // Contador: nota < 71

// Recorrido obligatorio con foreach
foreach ($notas as $nota) {
    $suma += $nota;                    // acumulador de suma
    if ($nota > $maxima) { $maxima = $nota; }
    if ($nota < $minima) { $minima = $nota; }
    if ($nota >= 71) { $aprobados++; } else { $reprobados++; }
}

$promedio = $suma / $cantidad; // operación aritmética: división
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Ejercicio 1 - Estadísticas de calificaciones</title>
<style>
    body { font-family: Arial, sans-serif; background:#f4f6f8; color:#222; padding:24px; }
    .card { max-width:640px; margin:0 auto; background:#fff; border-radius:10px;
            box-shadow:0 2px 8px rgba(0,0,0,.08); padding:24px; }
    h1 { font-size:1.3rem; color:#1a5fb4; margin-top:0; }
    ul.notas { columns:2; list-style:none; padding:0; }
    ul.notas li { padding:4px 8px; border-bottom:1px solid #eee; }
    table { border-collapse:collapse; width:100%; margin-top:12px; }
    th, td { border:1px solid #d0d7de; padding:8px 10px; text-align:left; }
    th { background:#1a5fb4; color:#fff; }
    td.num { text-align:right; font-weight:bold; }
</style>
</head>
<body>
<div class="card">
    <h1>Ejercicio 1: Estadísticas de calificaciones</h1>

    <h2>Listado de calificaciones (foreach)</h2>
    <ul class="notas">
        <?php foreach ($notas as $i => $nota): ?>
            <li>Estudiante <?= $i + 1 ?>: <strong><?= $nota ?></strong></li>
        <?php endforeach; ?>
    </ul>

    <h2>Resultados</h2>
    <table>
        <tr><th>Indicador</th><th>Valor</th></tr>
        <tr><td>Estudiantes evaluados</td><td class="num"><?= $cantidad ?></td></tr>
        <tr><td>Suma de calificaciones</td><td class="num"><?= $suma ?></td></tr>
        <tr><td>Promedio del grupo</td><td class="num"><?= number_format($promedio, 2) ?></td></tr>
        <tr><td>Calificación más alta</td><td class="num"><?= $maxima ?></td></tr>
        <tr><td>Calificación más baja</td><td class="num"><?= $minima ?></td></tr>
        <tr><td>Aprobados (nota &ge; 71)</td><td class="num"><?= $aprobados ?></td></tr>
        <tr><td>Reprobados (nota &lt; 71)</td><td class="num"><?= $reprobados ?></td></tr>
    </table>
</div>
</body>
</html>
